const SERVER_URL = 'http://203.110.240.55:80';
const RT_SUBMIT = '/submit';
const RT_BEGIN = '/begin';